Firefox插件FoxyProxy辅助添加白名单

用法：

将要添加白名单域名放到domain.txt，运行脚本

Python3 firefox-proxy.py